function showMenu(id) {
    let menu = document.getElementById(id);
    menu.classList.toggle('hidden');
}